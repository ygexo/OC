function showImageAlt(event) {
  const altText = event.target.alt;
  alert(`C'est une image : ${altText}`);
}

// Add event listener to each image
document.addEventListener('DOMContentLoaded', () => {
  const images = document.querySelectorAll('img');
  images.forEach((img) => {
    img.addEventListener('click', showImageAlt);
  });
});