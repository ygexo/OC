<?php
// Replace 'your_database_username', 'your_database_password', and 'your_database_name' with your actual database credentials
$servername = "localhost";
$username = "id21106324_basedn";
$password = "baseA1*ccc";
$dbname = "id21106324_base";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare the data for insertion
$name = $_POST['name'];
$email = $_POST['email'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];

// Insert the data into the database
$sql = "INSERT INTO avis (name, email, rating, comment) VALUES ('$name', '$email', '$rating', '$comment')";

if ($conn->query($sql) === TRUE) {
    echo "Votre avis a été enregistré avec succès.";
} else {
    echo "Erreur lors de l'enregistrement de l'avis: " . $conn->error;
}

$conn->close();
?>
